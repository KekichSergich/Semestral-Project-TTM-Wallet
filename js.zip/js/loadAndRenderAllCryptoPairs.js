import { CryptoPair } from './CryptoPair.js'; // путь адаптируй
import { getFromLocalStorage } from './storage.js';

export function loadAndRenderAllCryptoPairs() {
    const ul = document.querySelector(".currencies_grafs");
    ul.innerHTML = ""; // Очистить текущий список

    const storedPairs = getFromLocalStorage("storedCryptoPairs") || [];

    storedPairs.forEach(pairData => {
        const pair = new CryptoPair(pairData.name, pairData._price, pairData.image);
        pair.renderCryptoPair();
    });
}
