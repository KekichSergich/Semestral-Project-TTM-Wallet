function getDailyAmountsForPair(pairName) {
    const storedNotes = getFromLocalStorage("storedCryptoNotes") || [];

    const dailyTotals = {};

    storedNotes.forEach(note => {
        if (note.name !== pairName) return;

        const date = note.date;
        const amount = parseFloat(note.amount);
        if (!dailyTotals[date]) dailyTotals[date] = 0;
        dailyTotals[date] += amount;
    });

    const today = new Date();
    const last14Days = [];

    for (let i = 13; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const dateStr = date.toISOString().split("T")[0];
        last14Days.push({
            date: dateStr,
            amount: dailyTotals[dateStr] || 0
        });
    }

    return last14Days;
}



function drawLineChart(data) {
    const canvas = document.getElementById("cryptoChartCanvas");
    const ctx = canvas.getContext("2d");

    // Установка размеров в соответствии с .cryptoChart
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const padding = 40;
    const width = canvas.width - 2 * padding;
    const height = canvas.height - 2 * padding;

    const maxAmount = Math.max(...data.map(d => d.amount), 1); // ≥1 to avoid 0 division
    const xStep = width / (data.length - 1);
    const yScale = height / maxAmount;

    // Оси
    ctx.strokeStyle = "#ccc";
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.stroke();

    // Подписи X (даты)
    ctx.fillStyle = "gray";
    ctx.font = "10px Arial";
    ctx.textAlign = "center";
    data.forEach((point, i) => {
        const x = padding + i * xStep;
        const y = canvas.height - padding + 15;
        ctx.fillText(point.date.slice(5), x, y); // MM-DD
    });

    // Линия графика
    ctx.beginPath();
    ctx.strokeStyle = "#4fc3f7";
    data.forEach((point, i) => {
        const x = padding + i * xStep;
        const y = canvas.height - padding - point.amount * yScale;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);

        // Точки
        ctx.fillRect(x - 2, y - 2, 4, 4);
    });
    ctx.stroke();
}



function updateCryptoChart(symbol) {
    const data = getDailyAmountsForPair(symbol);
    drawLineChart(data);
}


document.addEventListener("DOMContentLoaded", () => {
    const select = document.getElementById("cryptoOptions");
    const storedNotes = getFromLocalStorage("storedCryptoNotes") || [];

    // Автоматически вставить доступные пары
    const uniquePairs = [...new Set(storedNotes.map(n => n.name))];
    uniquePairs.forEach(name => {
        const option = document.createElement("option");
        option.value = name;
        option.textContent = name.toUpperCase();
        select.appendChild(option);
    });

    if (select.options.length > 0) {
        updateCryptoChart(select.value);
    }

    select.addEventListener("change", () => {
        updateCryptoChart(select.value);
    });
});


updateCryptoChart(cryptoNoteName);
