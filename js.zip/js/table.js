import {clearStorageData} from "./storage.js";
import {loadAndRenderAllCryptoPairs} from "./loadAndRenderAllCryptoPairs.js";
import { triggerOverflowUpdate } from "./overflowObserver.js";
let resetDataButton = document.getElementById("resetDataButton");

function resetData() {
    clearStorageData();
    loadAndRenderAllCryptoPairs(); 
    triggerOverflowUpdate();
}

resetDataButton.addEventListener("click", resetData);